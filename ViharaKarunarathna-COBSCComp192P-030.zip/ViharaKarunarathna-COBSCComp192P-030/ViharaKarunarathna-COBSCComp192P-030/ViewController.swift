//
//  ViewController.swift
//  ViharaKarunarathna_COBSCComp192P_030


import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

